update dogovor
set ostatok=ostatok - tarif
where data >= '2003-04-01'
