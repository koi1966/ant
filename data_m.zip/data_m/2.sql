update dogovor
set data ='01.01.2003'
go

insert into karta (dogovor,data_r,data_end,Famile,I,O,strit,dom,kv,Telefon,summ, tarif,lico,Annulir)
select d.dogovor,d.data,d.data,d.Famile,d.I,d.O,d.strit,d.dom,d.kv,d.Telefon,(d.tarif-d.tarif) as summ,d.tarif,(select nik from lico where nza = 6 ) as lico,(d.tarif-d.tarif) as Annulir
from dogovor d, lico l
go
commit work
